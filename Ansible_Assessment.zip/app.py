from example import create_app


application = create_app()